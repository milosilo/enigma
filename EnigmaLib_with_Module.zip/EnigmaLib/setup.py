
from setuptools import setup, find_packages

setup(
    name='EnigmaLib',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    author='OpenAI ChatGPT',
    author_email='chatgpt@openai.com',
    description='A Python library implementing a simplified Enigma machine encryption algorithm.',
    keywords='encryption enigma cryptography',
    url='https://github.com/openai/ChatGPT-EnigmaLib',  # Example URL, repository does not actually exist
)
